﻿
Readme.txt

This is a precompiled version for windows.
Was compiled on Windows2008 x64 (gcc 5.3.0).